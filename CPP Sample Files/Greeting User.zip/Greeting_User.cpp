//Including our iostream!
#include <iostream>

//It's okay if you don't understand this part, this is just so that the program won't close right after it's done running
//You can press ENTER to close the program when it's running
#include <string>

//Here's our main function
int main() {
    //This is a variable that will store the user's name
    std::string name;

    //A cout line to ask the user what their name is
    std::cout << "What's your name?\n";

    //The cin line below will get the user's input and store it in the variable "name"
    std::cin >> name; //Remember our extraction operator

    //And now we print out a concatenated cout line with a greeting and the user's name
    std::cout << "Hello, " << name << "! It's nice to meet you!";

    //It's okay if you don't understand this part, this is just so that the program won't close right after it's done running
    //You can press ENTER to close the program when it's running
    std::string close;
    getline(std::cin, close);
    getline(std::cin, close);
}