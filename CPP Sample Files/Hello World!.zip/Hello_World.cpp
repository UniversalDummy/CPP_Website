//Notice the file extention to this file? It's .cpp!

//Remember this? It's your iostream library!
#include <iostream>

//It's okay if you don't understand this part, this is just so that the program won't close right after it's done running
//You can press ENTER to close the program when it's running
#include <string>

//We need this function in every CPP program somewhere
int main() {

    //Cout line
    std::cout << "Hello World!";

    //It's okay if you don't understand this part, this is just so that the program won't close right after it's done running
    //You can press ENTER to close the program when it's running
    std::string close;
    getline(std::cin, close);
}