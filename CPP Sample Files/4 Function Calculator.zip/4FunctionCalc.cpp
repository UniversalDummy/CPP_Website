//Including the iostream library!
#include <iostream>

//It's okay if you don't understand this part, this is just so that the program won't close right after it's done running
//You can press ENTER to close the program when it's running
#include <string>

//Our main function
int main() {

    //A variable to store our user's input numbers
    double number;

    //A variable to store the user's result
    double result;


    //A cout line to ask the user to enter a number
    std::cout << "Please input a number: ";

    //A cin line to get the user's starting number. We are storing their first input inside of the "result" variable
    std::cin >> result;

    //Don't worry about this line here, we're gonna expain it later in this file
    operation:

    /*
    A variable to store the user's operator they select. The reason we add an "_" (underscore) to the variable name is that the word "operator" in C++ is a keyword,
    and we can't have a variable name be keyword or anything else that C++ looks at as a line of code rather than a name
    */
    int _operator;

    //Ask the user what operator they would like to use
    std::cout << "\nChoose an operator: " << "\n1. Add (+)" << "\n2. Subtract (-)" << "\n3. Multiply (*)" << "\n4. Divide (/)" << "\n5. Equal (=)";

    //
    std::cout << "\n\nENTER OPTION NUMBER: ";

    //Get user's input operator:
    std::cin >> _operator;

    //This "if" statement just checks to make sure that the user didn't input the "equal" operator. If they did then the program will skip past this and will not obtain the user's input
    //It's okay if you don't understand what the "!" means. That basically means "not". So this would say "if the _operator variable is NOT equal to 5, then..."
    if(_operator != 5) {
        //A cout line to tell the user to put in their next number
        std::cout << "\nPlease input a number: ";

        //A cin line to get the user's ever changing number. We are storing their input inside of the "number" variable
        std::cin >> number;
    }

    //A couple of line breaks to keep things readable
    std::cout << "\n\n\n";

    //It's okay if you don't understand this yet. Think of it as a giant "if-else" statement that is cleaner and easier to read


    switch(_operator) { //This right here takes in the "_operator" variable and applies it to whatever case it matches

        case 1: //If the _operator is set to 1
            //Print out operation so that the user can see the equation
            std::cout << result << " + " << number << " = ";
            
            //Add the number to the result
            result += number;

            //Print out answer to the problem and a couple of line breaks
            std::cout << result << "\n\n";

            //It's okay if you don't understand this yet, but this next line is super easy to learn
            goto operation; //Remember that "operation" word from earlier in the code? This line basically "goes to" that word in the program to start from where it's placed, meaning it will run all this code again

            //This line stops the code at this point inside of this case statement. Because we don't need to run anymore code in this case statement, we break it here at the end
            //(It may not be very necessary to include it here because we are using the "goto" above, which will stop the case statement anyway)
            break;

        case 2: //If the _operator is set to 2
            //Print out operation so that the user can see the equation
            std::cout << result << " - " << number << " = ";
            
            //Subtract the number from the result
            result -= number;

            //Print out answer to the problem and a couple of line breaks
            std::cout << result << "\n\n";

            //It's okay if you don't understand this yet, but this next line is super easy to learn
            goto operation; //Remember that "operation" word from earlier in the code? This line basically "goes to" that word in the program to start from where it's placed, meaning it will run all this code again

            //This line stops the code at this point inside of this case statement. Because we don't need to run anymore code in this case statement, we break it here at the end
            //(It may not be very necessary to include it here because we are using the "goto" above, which will stop the case statement anyway)
            break;

        case 3: //If the _operator is set to 3
            //Print out operation so that the user can see the equation
            std::cout << result << " * " << number << " = ";
            
            //Multiply the number by the result
            result = result * number;

            //Print out answer to the problem and a couple of line breaks
            std::cout << result << "\n\n";

            //It's okay if you don't understand this yet, but this next line is super easy to learn
            goto operation; //Remember that "operation" word from earlier in the code? This line basically "goes to" that word in the program to start from where it's placed, meaning it will run all this code again

            //This line stops the code at this point inside of this case statement. Because we don't need to run anymore code in this case statement, we break it here at the end
            //(It may not be very necessary to include it here because we are using the "goto" above, which will stop the case statement anyway)
            break;

        case 4: //If the _operator is set to 4
            //Print out operation so that the user can see the equation
            std::cout << result << " / " << number << " = ";
            
            //Divide the result by number
            result = result / number;

            //Print out answer to the problem and a couple of line breaks
            std::cout << result << "\n\n";

            //It's okay if you don't understand this yet, but this next line is super easy to learn
            goto operation; //Remember that "operation" word from earlier in the code? This line basically "goes to" that word in the program to start from where it's placed, meaning it will run all this code again

            //This line stops the code at this point inside of this case statement. Because we don't need to run anymore code in this case statement, we break it here at the end
            //(It may not be very necessary to include it here because we are using the "goto" above, which will stop the case statement anyway)
            break;

        case 5: //If the _operator is set to 5
            //Print out the final result of the equation, since this is the "equal" operator
            std::cout << "\n\n\nYour result is: " << result << "\n\n\n";

            //It's okay if you don't understand this part, this is just so that the program won't close right after it's done running
            //You can press ENTER to close the program when it's running
            std::string close;
            getline(std::cin, close);
            getline(std::cin, close);

            //This line ends the whole program. It's okay if you don't understand it yet
            return 0;

            //This line stops the code at this point inside of this case statement. Because we don't need to run anymore code in this case statement, we break it here at the end
            //(It may not be very necessary to include it here because we are using the "return" above, which will stop the case statement anyway and close the program)
            break;
    }

}